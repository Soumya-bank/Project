package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.entity.TicketBooking;
import com.airline.repository.TicketRepository;
import com.airline.util.TicketConverter;

@SpringBootTest
public class TicketServiceTest {

	@Autowired
	TicketBookingService ticketBookingService;
	
	@MockBean
	TicketRepository ticketRepository;
	
	@Autowired
	TicketConverter ticketConverter;
	
	@Test
	void bookFlightTest()
	{	
		Flight flight = Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-10")).time("10:30").source("kolkata").
				destination("bangalore").travellerClass("business").build();
		
		Airline air = Airline.builder().airlineName("air india").fare(3300.37f).build();

		Passenger passenger = Passenger.builder().name("pallab").email("pal@gmail.com").
				phno("9812764509").userName("pallab").password("pal123").role("user").build();
		
		TicketBooking ticket = TicketBooking.builder().noOfPassenger(2).date(LocalDate.now()).
				source("kolkata").destination("delhi").build();
		
		Mockito.when(ticketRepository.save(ticket)).thenReturn(ticket);
		//assertThat(ticketBookingService.bookFlight(flight.getFlightId(),passenger.getId() , ticket)).isEqualTo("Your ticket has been booked successfully!!");
		assertEquals(ticket.getNoOfPassenger(), 2);
	}
	
	@Test
	@DisplayName("Negative Test Case")
	void cancelBookingTest()
	{
		TicketBooking ticket = TicketBooking.builder().noOfPassenger(2).date(LocalDate.now()).
				source("kolkata").destination("delhi").build();
		
		Optional<TicketBooking> opt= Optional.of(ticket);
		Mockito.when(ticketRepository.findById(opt.get().getTicketId())).thenReturn(opt);
		
		assertThat(ticketBookingService.cancelBooking(opt.get().getTicketId())).isEqualTo("Deleted");
	}
}
