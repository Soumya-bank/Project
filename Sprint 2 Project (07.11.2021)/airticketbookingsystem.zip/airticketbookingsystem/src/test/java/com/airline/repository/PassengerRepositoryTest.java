package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.airline.entity.Passenger;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PassengerRepositoryTest {

	@Autowired
	PassengerRepository passengerRepository;
	
	@Test
	//@Rollback(value = false)
	@Order(1)
	void savePassengerTest()
	{
		Passenger passenger = Passenger.builder().name("randhir").email("ran@gmail.com").
				phno("9876543211").userName("randhir").password("ran123").role("user").build();
		
		Passenger p=passengerRepository.save(passenger);
		
		assertThat(p.getName()).isEqualTo("randhir");
	}
	
	@Test
	@Order(2)
	void getAllPassengerTest()
	{
		List<Passenger> list= passengerRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
	}
	
	@Test
	//@Rollback(value = false)
	@Order(3)
	void updatePassengerTest()
	{
		Passenger existingp= passengerRepository.findById(3).get();
		existingp.setName("nilanjan");
		Passenger p=passengerRepository.save(existingp);
		assertThat(p.getName()).isEqualTo("nilanjan");
	}
	
	@Test
	@Order(4)
	void deletePassengerTest()
	{
		passengerRepository.deleteById(6);
		assertThrows(NoSuchElementException.class, ()-> passengerRepository.findById(6).get());
	}
	
	@Test
	@Order(5)
	@DisplayName("Negative Test case")
	void updatePassengerNegativeTest()
	{
		Passenger existingp= passengerRepository.findById(3).get();
		existingp.setName("nilanjan");
		Passenger p=passengerRepository.save(existingp);
		assertThat(p.getName()).isEqualTo("soumya");
	}
}
