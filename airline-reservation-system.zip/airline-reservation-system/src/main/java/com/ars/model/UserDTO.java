package com.ars.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserDTO {
	
	private int id;
	
	private String UserName;
	
	private String password;
}
